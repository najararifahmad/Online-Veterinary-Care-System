﻿using BAL;
using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Online_Veterinary_Care_System.Areas.user.Controllers
{
    public class UserController : Controller
    {
        // GET: user/User
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Appointments()
        {
            return View();
        }

        public ActionResult BookAppointment()
        {
            return View();
        }
        public ActionResult ChangePassword()
        {
            return View();
        }
        public ActionResult Chat(string receiver)
        {
            return View();
        }
        public ActionResult Messages()
        {
            UserBAL _bal = new UserBAL();
            IEnumerable<User> doctors = _bal.GetActiveDoctors();
            return View(doctors);
        }
    }
}