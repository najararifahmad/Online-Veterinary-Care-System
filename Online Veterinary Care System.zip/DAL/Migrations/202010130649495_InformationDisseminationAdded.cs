﻿namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InformationDisseminationAdded : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.InformationDisseminations",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        InformationText = c.String(),
                        FilePath = c.String(),
                        AddedOn = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.InformationDisseminations");
        }
    }
}
